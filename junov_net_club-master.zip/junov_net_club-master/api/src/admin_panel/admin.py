from django.contrib import admin
from src.models.category import Category
from src.models.stack import Stack


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'name'
    )


@admin.register(Stack)
class StackAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'name'
    )
