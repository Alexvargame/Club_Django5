from .repository import ProjectRepository
from .dtos.request.create_project_dto import CreateProjectDTO


class ProjectService:
    def __init__(self):
        self.repository = ProjectRepository()

    def create_project(self, dto: CreateProjectDTO) -> None:
        self.repository.create_project(dto)
