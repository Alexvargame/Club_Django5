from django import forms
from src.models.enums import Status, Role


class ProjectCreateForm(forms.Form):
    # def __init__(self, stacks, *args, **kwargs):
    #     super().__init__(*args, **kwargs)
    #     self.fields["stacks"] = forms.MultipleChoiceField(
    #         required=False,
    #         # widget=forms.CheckboxSelectMultiple,
    #         choices=stacks,
    #     )

    name = forms.CharField(max_length=255)
    description = forms.CharField(max_length=5000, widget=forms.Textarea)
    repo_link = forms.CharField(max_length=255)
    status = forms.ChoiceField(choices=Status)
    author_role = forms.ChoiceField(choices=Role)
    deadline = forms.DateTimeField()
    categories = forms.CharField(max_length=255)
    stacks = forms.CharField(max_length=255)
